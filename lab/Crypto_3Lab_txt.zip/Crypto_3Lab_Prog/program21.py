#  GCD and coprimes
import math

a = int(input("Enter first integer: "))
b = int(input("Enter second integer: "))

gcd = math.gcd(a, b)
print("GCD:", gcd)
print("Coprime:", gcd == 1)
