#  chr() conversion
values = [65, 67, 73, 80, 72, 69, 82]
word = "".join(chr(value) for value in values)

print("Characters:", [chr(value) for value in values])
print("Word:", word)

#chr() is the inverse of ord() and converts an integer (Unicode code point) to its corresponding character.
#[] is a list comprehension, which is a compact way to create a list by iterating over a sequence and applying a function to each element.
#used for loop in [] to iterate over the values list and apply the chr() function to each value, converting it to its corresponding character.
