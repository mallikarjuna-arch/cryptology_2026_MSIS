variables = {
    "int": 42,
    "float": 3.14159,
    "complex": 2 + 3j,
    "str": "Cryptology Lab",
    "list": [1, 2, 3, 4, 5],
    "tuple": (10, 20, 30),
    "set": {1, 2, 3, 4, 5},
    "dictionary": {"name": "Alice", "age": 20}
}
for name, value in variables.items():
    print(f"{name:12} : {value!r:30} : {type(value).__name__}")

