# Character grouping
message = input("Enter a string: ").replace(" ", "")

for i in range(0, len(message), 5):
    print(message[i:i + 5])

#5 is the group size, and the loop iterates through the string in steps of 5, printing each group of 5 characters.
#i:i is 