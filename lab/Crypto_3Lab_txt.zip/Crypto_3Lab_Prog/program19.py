# Alphabet representation
ch = input("Enter an uppercase character: ").strip().upper()

if len(ch) == 1 and "A" <= ch <= "Z":
    print(f"{ch} -> {ord(ch) - ord('A')}")
else:
    print("Please enter a single uppercase alphabet.")

num = int(input("Enter number (0-25): "))
if 0 <= num <= 25:
    print(f"{num} -> {chr(num + ord('A'))}")
else:
    print("Number must be between 0 and 25.")
