# Character frequency
text = "CRYPTOLOGYISINTERESTING"

frequency = {}
for ch in text:
    frequency[ch] = frequency.get(ch, 0) + 1

for ch, count in frequency.items():
    print(f"{ch} : {count}")

most_frequent = max(frequency, key=frequency.get)
print("Most frequently occurring character:", most_frequent)

#get() is a method of the dictionary that returns the value for a given key. If the key is not found, it returns a default value (in this case, 0). This is used to count the frequency of each character in the text.
# 0 is the default value returned by get() when the character is not found in the frequency dictionary. This means that if a character is not already in the dictionary, it will be added with a count of 0, and then incremented by 1.

# ch and count are the key-value pairs in the frequency dictionary. ch represents the character, and count represents the number of times that character appears in the text. The loop iterates through each key-value pair in the dictionary and prints them.
# frequency.items() is a method that returns a view object containing the key-value pairs of the frequency dictionary. This allows us to iterate through the dictionary and access both the character (key) and its count (value) in the loop.

#eg if text is aabbcc, then frequency will be {'a': 2, 'b': 2, 'c': 2}, in frequency.items(), ch will be 'a', 'b', 'c' and count will be 2, 2, 2 respectively. The loop will print:
# a : 2
#items() is a method that returns a view object containing the key-value pairs of the frequency dictionary. This allows us to iterate through the dictionary and access both the character (key) and its count (value) in the loop.
