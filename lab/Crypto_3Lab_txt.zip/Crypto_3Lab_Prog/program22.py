# Multiplicative inverse
# The multiplicative inverse of b modulo m exists when gcd(b, m) = 1.

import math

b = int(input("Enter integer b: "))
m = int(input("Enter modulus: "))

if math.gcd(b, m) != 1:
    print("Multiplicative inverse does not exist.")
else:
    inverse = pow(b, -1, m)
    print(f"Multiplicative inverse of {b} modulo {m} is {inverse}")
