#String methods
message = "CRYPTOLOGY USING PYTHON"

print("Lowercase:", message.lower())
print("Uppercase:", message.upper())
print('"PYTHON" exists:', "PYTHON" in message)
print("Replaced:", message.replace("PYTHON", "PROGRAMMING"))
print("Split:", message.split(" "))
print("Joined:", " ".join(message.split(" ")))