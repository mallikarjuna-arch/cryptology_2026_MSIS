# Unicode/ASCII values
message = "CRYPTOLOGY USING PYTHON"

for ch in message:
    print(f"{ch} -> {ord(ch)}")
